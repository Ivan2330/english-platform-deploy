from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List

from app.core.database import get_async_session
from app.models.classrooms.classroom import Classroom
from app.models.connection.call import Call
from app.models.connection.chat import Chat
from app.models.users.users import User, Status
from app.schemas.classrooms.classroom import ClassroomCreate, ClassroomResponse, ClassroomUpdate
from app.api.users.auth import current_active_user
from app.core.cache import set_cache, get_cache, delete_cache

router = APIRouter(prefix="/classrooms", tags=["Classrooms"])


def is_admin(current_user: User):
    """Перевіряє, чи є користувач адміністратором."""
    if current_user.role != "STAFF" or current_user.status != Status.ADMIN:
        raise HTTPException(status_code=403, detail="User is not authorized as admin")


# 🔹 Створення класу (тільки для адміністраторів)
@router.post("/", response_model=ClassroomResponse)  
async def create_classroom(
    classroom: ClassroomCreate,
    session: AsyncSession = Depends(get_async_session),
    current_user: User = Depends(current_active_user),
):
    """Створює новий клас. Доступно лише адміністраторам."""
    
    is_admin(current_user)  # Перевірка, чи це адміністратор
    
    new_classroom = Classroom(**classroom.model_dump())
    session.add(new_classroom)
    await session.commit()
    await session.refresh(new_classroom)

    # Очищення кешу після змін
    await delete_cache("classrooms_list")

    return new_classroom


# 🔹 Отримання всіх класів
@router.get("/", response_model=List[ClassroomResponse])
async def classrooms_list(
    session: AsyncSession = Depends(get_async_session),
    current_user: User = Depends(current_active_user),
):
    """Отримує список усіх класів."""
    
    cached_data = await get_cache("classrooms_list")
    if cached_data:
        return cached_data

    result = await session.execute(select(Classroom))
    classrooms = result.scalars().all()

    await set_cache("classrooms_list", classrooms, ttl=600)
    
    return classrooms



# 🔹 Отримання деталей класу з дзвінками та чатами
@router.get("/{classroom_id}/details", response_model=ClassroomResponse)
async def get_classroom_details(
    classroom_id: int,
    session: AsyncSession = Depends(get_async_session),
    current_user: User = Depends(current_active_user),
):
    cache_key = f"classroom_{classroom_id}_details"
    cached_data = await get_cache(cache_key)
    if cached_data:
        return cached_data

    result = await session.execute(select(Classroom).where(Classroom.id == classroom_id))
    classroom = result.scalar_one_or_none()
    if not classroom:
        raise HTTPException(status_code=404, detail="Classroom not found.")

    calls_result = await session.execute(select(Call).where(Call.classroom_id == classroom_id))
    classroom.calls = calls_result.scalars().all()

    chats_result = await session.execute(select(Chat).where(Chat.classroom_id == classroom_id))
    classroom.chats = chats_result.scalars().all()

    await set_cache(cache_key, classroom, ttl=600)
    return classroom


# 🔹 Оновлення класу (тільки для адміністраторів)
@router.put("/{classroom_id}", response_model=ClassroomResponse)
async def update_classroom(
    classroom_id: int,
    classroom: ClassroomUpdate,
    session: AsyncSession = Depends(get_async_session),
    current_user: User = Depends(current_active_user),
):
    is_admin(current_user)

    result = await session.execute(select(Classroom).where(Classroom.id == classroom_id))
    existing_classroom = result.scalar_one_or_none()
    if not existing_classroom:
        raise HTTPException(status_code=404, detail="Classroom not found.")

    for key, value in classroom.model_dump(exclude_unset=True).items():
        setattr(existing_classroom, key, value)

    session.add(existing_classroom)
    await session.commit()
    await session.refresh(existing_classroom)
    return existing_classroom


# 🔹 Видалення класу (тільки для адміністраторів)
@router.delete("/{classroom_id}")
async def delete_classroom(
    classroom_id: int,
    session: AsyncSession = Depends(get_async_session),
    current_user: User = Depends(current_active_user),
):
    is_admin(current_user)

    result = await session.execute(select(Classroom).where(Classroom.id == classroom_id))
    classroom = result.scalar_one_or_none()
    if not classroom:
        raise HTTPException(status_code=404, detail="Classroom not found.")

    await session.delete(classroom)
    await session.commit()
    await delete_cache(f"classroom_{classroom_id}_details")
    return {"detail": "Classroom deleted successfully."}
